cap clear all
set more off
cap log close
set varabbrev off

loc extract_date = "202603013"

/***********/
/* HISTORY */
/***********/
	
//20250619: first stage results

//20260312: adding on alternate specs: zero check pass and alt "winsorized" tasa_ir
	
/*********/
/* NOTES */
/*********/

/***************************/
/* JAKOB LOCAL ENVIRONMENT */
/***************************/

/*
local today: di %tdCYND daily("$S_DATE", "DMY")
local month = substr("`today'", 1, 6)

glob localdir "/Users/jakob_brounstein/Dropbox/ecuador_transparency"
glob mydatadir "$localdir/data/local_simulation"
glob datadir "$localdir/data/local_simulation"
glob dodir "$localdir/do"
glob logdir "$localdir/logs"

glob graphdir "$localdir/local_simulation"
glob texdir "$localdir/local_simulation"

cap n mkdir "$localdir/local_simulation/resultados"

//export directory
cap n mkdir "$localdir/local_simulation/resultados/`today'"
cap n mkdir "$localdir/local_simulation/resultados/`today'/reportes"
glob outdir "$localdir/local_simulation/resultados/`today'/reportes"

log using "$logdir/main_ownership_results_`today'.smcl", replace

loc time0 = "$S_TIME"
loc date0 = "$S_DATE"

di "started: `time0' `date0'"

sca local_environment = 1

timer clear
timer on 1  
*/

/*******************/
/* SRI ENVIRONMENT */
/*******************/

local today: di %tdCYND daily("$S_DATE", "DMY")
local month = substr("`today'", 1, 6)

glob localdir "D:\BM_EXTENSION\B202106_JAKOB_BROUNSTEIN"

//alt
/*
glob localdir "F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN"
sysdir set PLUS F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN\Ado\ado_1\plus
sysdir set PERSONAL F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN\Ado\ado\plus
*/

glob logdir "$localdir\logs"
glob dumpdir "$localdir\dump"
glob datadir "$localdir/data/transparency"
glob graphdir "$localdir/out"
glob texdir "$localdir/out"

//export directory
cap n mkdir "$localdir/resultados/`extract_date'"
cap n mkdir "$localdir/resultados/`extract_date'/reportes"
glob outdir "$localdir/resultados/`extract_date'/reportes"

log using "$logdir/first_stage_results_`today'.smcl", replace

loc time0 = "$S_TIME"
loc date0 = "$S_DATE"

di "started: `time0' `date0'"

timer clear
timer on 1  

/***************/
/* REGRESSIONS */
/***************/

//24 permutations regressions

cap postclose first_stage
postfile first_stage str32(var) double(coef stderr N r2) using "$outdir/first_stage.dta", replace

///
//MAIN SAMPLE
///	
use "$datadir/main_panel.dta", clear

//new tasa_ir
gen tasa_ir_alt = tasa_ir if tasa_ir != 0
	replace	tasa_ir_alt = .22 if tasa_ir > 0 & tasa_ir < .22 & tasa_ir != . & tasa_ir != 0
	replace	tasa_ir_alt = .25 if tasa_ir > .25 & tasa_ir != . & tasa_ir != 0

bys firm_id: gegen prominent_2015 = max(cond(anio_fiscal == 2015 & participation_prominent >= 50, 1, 0))

gen l_cit_liability = log(cit_liability)

bys firm_id: gegen consistent_count_2015_2017 = total(cond(inrange(anio_fiscal, 2015, 2017) & round(porcentaje_pff - porcion_comp_soc_si_inf_3578, 1) == 0, 1, 0))
gen consistent_2015_2017 = consistent_count_2015_2017 == 3

foreach y in tasa_ir tasa_ir_alt {
	
	//1. main, none
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 0, cit_condition, 0, consistent_condition, 0) detail(scalars)

	//2. main, cit
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 0, cit_condition, 1, consistent_condition, 0) detail(scalars)
		
	//3. main, prominent2015
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if prominent_2015 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 1, cit_condition, 0, consistent_condition, 0) detail(scalars)

	//4. main, consistent
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 0, cit_condition, 0, consistent_condition, 1) detail(scalars)
		
	//4b. main, not consistent
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if consistent_2015_2017 == 0, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 0, cit_condition, 0, consistent_condition, -1) detail(scalars)	
		
	//5. main, cit + prominent
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & prominent_2015 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 1, cit_condition, 1, consistent_condition, 0) detail(scalars)
			
	//6. main, cit + consistent
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 0, cit_condition, 1, consistent_condition, 1) detail(scalars)
		
	//6b. main, cit + not consistent
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & consistent_2015_2017 == 0, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 0, cit_condition, 1, consistent_condition, -1) detail(scalars)	
			
	//7. main, prominent + consistent
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if prominent_2015 == 1 & consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 1, cit_condition, 0, consistent_condition, 1) detail(scalars)
		
	//7b. main, prominent + not consistent
	reghdfe `y' b0.treatment_major##b2014.i.anio_fiscal if prominent_2015 == 1 & consistent_2015_2017 == 0, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 1, cit_condition, 0, consistent_condition, -1) detail(scalars)
		
	//8. main, cit + prominent + consistent
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & prominent_2015 == 1 & consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 1, cit_condition, 1, consistent_condition, 1) detail(scalars)
		
	//8b. main, cit + prominent + not consistent
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & prominent_2015 == 1 & consistent_2015_2017 == 0, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, `y', sample, "main_panel_majors", prominent_condition, 1, cit_condition, 1, consistent_condition, -1) detail(scalars)	

	/*	
	///
	//ALL HAVENS VERSUS LATIN NONHAVENS SAMPLE
	///

	use "$datadir/geo_alt_3_panel.dta", clear

	bys firm_id: gegen prominent_2015 = max(cond(anio_fiscal == 2015 & participation_prominent >= 50, 1, 0))

	gen l_cit_liability = log(cit_liability)

	bys firm_id: gegen consistent_count_2015_2017 = total(cond(inrange(anio_fiscal, 2015, 2017) & round(porcentaje_pff - porcion_comp_soc_si_inf_3578, 1) == 0, 1, 0))
	gen consistent_2015_2017 = consistent_count_2015_2017 == 3

	//9. geo_alt_3, none
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 0, cit_condition, 0, consistent_condition, 0) detail(scalars)

	//10. geo_alt_3, cit
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 0, cit_condition, 1, consistent_condition, 0) detail(scalars)
		
	//11. geo_alt_3, prominent2015
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if prominent_2015 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 1, cit_condition, 0, consistent_condition, 0) detail(scalars)

	//12. geo_alt_3, consistent
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 0, cit_condition, 0, consistent_condition, 1) detail(scalars)
		
	//13. geo_alt_3, cit + prominent
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & prominent_2015 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 1, cit_condition, 1, consistent_condition, 0) detail(scalars)
			
	//14. geo_alt_3, cit + consistent
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 0, cit_condition, 1, consistent_condition, 1) detail(scalars)
			
	//15. geo_alt_3, prominent + consistent
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if prominent_2015 == 1 & consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 1, cit_condition, 0, consistent_condition, 1) detail(scalars)
		
	//16. geo_alt_3, cit + prominent + consistent
	reghdfe tasa_ir b0.treatment_major##b2014.i.anio_fiscal if missing(l_cit_liability) == 0 & prominent_2015 == 1 & consistent_2015_2017 == 1, absorb(anio_fiscal firm_id) cluster(firm_id)

		regsave using "$outdir/first_stage.dta", append autoid addlabel(depvar, tasa_ir, sample, "geo_alt_3_panel_majors", prominent_condition, 1, cit_condition, 1, consistent_condition, 1) detail(scalars)
	*/

}
	
cap postclose first_stage

///
//DESCRIPTIVE STATS FILE
///

gen porcion_comp_soc_si_inf_3578_g = 1 if porcion_comp_soc_si_inf_3578 == 0
	replace porcion_comp_soc_si_inf_3578_g = 2 if porcion_comp_soc_si_inf_3578 > 0 & porcion_comp_soc_si_inf_3578 < 50 & missing(porcion_comp_soc_si_inf_3578) == 0
	replace porcion_comp_soc_si_inf_3578_g = 3 if porcion_comp_soc_si_inf_3578 >= 50 & missing(porcion_comp_soc_si_inf_3578) == 0
	replace porcion_comp_soc_si_inf_3578_g = 4 if missing(porcion_comp_soc_si_inf_3578) == 1
	
gen porcentaje_pff_groups = 1 if porcentaje_pff == 0
	replace porcentaje_pff_groups = 2 if porcentaje_pff > 0 & porcentaje_pff < 50 & missing(porcentaje_pff) == 0
	replace porcentaje_pff_groups = 3 if porcentaje_pff >= 50 & missing(porcentaje_pff) == 0
	replace porcentaje_pff_groups = 4 if missing(porcentaje_pff) == 1	
	
gen n = 1

gen m_porcentaje_pff = missing(porcentaje_pff)
gen m_porcion_comp_soc_si_inf_3578 = missing(porcion_comp_soc_si_inf_3578)

gen b_cit_liability = missing(l_cit_liability) == 0

preserve

	gcollapse (sum) n (mean) m_porcentaje_pff m_porcion_comp_soc_si_inf_3578 tasa_ir_mean = tasa_ir tasa_ir_alt_mean = tasa_ir_alt (sd) tasa_ir_sd = tasa_ir tasa_ir_alt_sd = tasa_ir_alt (p50) tasa_ir_p50 = tasa_ir tasa_ir_alt_p50 = tasa_ir_alt (p10) tasa_ir_p10 = tasa_ir tasa_ir_alt_p10 = tasa_ir_alt (p90) tasa_ir_p90 = tasa_ir tasa_ir_alt_p90 = tasa_ir_alt, by(group anio_fiscal porcentaje_pff_groups porcion_comp_soc_si_inf_3578_g b_cit_liability)

	save "$outdir/first_stage_coarse.dta", replace
	
restore
	
/*******/
/* END */
/*******/

timer off 1 

loc time1 = "$S_TIME"
loc date1 = "$S_DATE"

di "started: `time0' `date0'"
di "ended: `time1' `date1'"

timer list 
di "elapsed time: `r(t1)' seconds"

di "file first_stage_results has terminated successfully"

cap log close
clear
