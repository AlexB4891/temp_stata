cap clear all
set more off
cap log close
set varabbrev off

loc extract_date = "202603013"

/***********/
/* HISTORY */
/***********/
	
//20250606: bo_2014
	
//20250610: continuing build	
		
//20250617: adding on descriptives

//20250729: fixing bo group definitions (groups were discrepant with actual scaling of b0_2014)

//20250731: including the post coefficient in the dd regressions

/*********/
/* NOTES */
/*********/

/*
/***************************/
/* JAKOB LOCAL ENVIRONMENT */
/***************************/

local today: di %tdCYND daily("$S_DATE", "DMY")
local month = substr("`today'", 1, 6)

glob localdir "/Users/jakob_brounstein/Dropbox/ecuador_transparency"
glob mydatadir "$localdir/data/local_simulation"
glob datadir "$localdir/data/local_simulation"
glob dodir "$localdir/do"
glob logdir "$localdir/logs"

glob graphdir "$localdir/local_simulation"
glob texdir "$localdir/local_simulation"

cap n mkdir "$localdir/local_simulation/resultados"

//export directory
cap n mkdir "$localdir/local_simulation/resultados/`today'"
cap n mkdir "$localdir/local_simulation/resultados/`today'/reportes"
glob outdir "$localdir/local_simulation/resultados/`today'/reportes"

//log using "$outdir/mean_reversion_`today'.smcl", replace

loc time0 = "$S_TIME"
loc date0 = "$S_DATE"

di "started: `time0' `date0'"

timer clear
timer on 1  
*/

/*******************/
/* SRI ENVIRONMENT */
/*******************/

local today: di %tdCYND daily("$S_DATE", "DMY")
local month = substr("`today'", 1, 6)

glob localdir "D:\BM_EXTENSION\B202106_JAKOB_BROUNSTEIN"

//alt environment
/*
glob localdir "F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN"
sysdir set PLUS F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN\Ado\ado_1\plus
sysdir set PERSONAL F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN\Ado\ado\plus
*/

cap n mkdir "$localdir/resultados"

glob logdir "$localdir\logs"
glob dumpdir "$localdir\dump"
glob datadir "$localdir/data/transparency"
glob graphdir "$localdir/out"
glob texdir "$localdir/out"

//export directory
cap n mkdir "$localdir/resultados/`extract_date'"
cap n mkdir "$localdir/resultados/`extract_date'/reportes"
glob outdir "$localdir/resultados/`extract_date'/reportes"

log using "$outdir/bo_2014_`today'.smcl", replace

loc time0 = "$S_TIME"
loc date0 = "$S_DATE"

di "started: `time0' `date0'"

timer clear
timer on 1  

/***********/
/* BO 2014 */
/***********/

cap postclose bo_2014
postfile bo_2014 str32(var) double(coef stderr N r2) using "$outdir/bo_2014.dta", replace

use "$datadir/main_panel.dta", replace

//keeping majors
keep if missing(treatment_major) == 0
ren treatment_major treatment

keep firm_id anio_fiscal treatment aps f101 active aps_f101 aps_f101_active porcentaje_pff porcentaje_ext porcentaje_nac porcentaje_vac percent_declarado incomplete complete inconsistent aps_residual aps_residual_0 aps_residual_pais aps_residual_pais_other average_chain_length max_chain_length b_average_chain_length b_max_chain_length max_shareholder beneficiarios_pff beneficiarios_ext beneficiarios_nac beneficiarios_vac beneficiarios_10_pff beneficiarios_10_ext beneficiarios_10_nac beneficiarios_10_vac terminal_ownership_conc terminal_owners_10 terminal_owners participation_prominent participation_prominent_0 participation_inv_prominent intermediate_pff intermediate_ext intermediate_nac intermediate_vac intermediate_prominent intermediate_10_pff intermediate_10_ext intermediate_10_nac intermediate_10_vac intermediate_10_prominent intermediate_50_pff intermediate_50_ext intermediate_50_nac intermediate_50_vac intermediate_100_pff intermediate_pff_max intermediate_50_prominent intermediate_100_ext intermediate_100_prominent intermediate_inv_prominent intermediate_10_inv_prominent intermediate_50_inv_prominent intermediate_100_inv_prominent empresa_extranjera persona_extranjera persona_nacional empresa_pff persona_pff empresa_nacional persona_foreign empresa_foreign bf_persona bf_persona_100 any_bf_persona bf_empresa bf_persona_alt bf_persona_r persona_prominent bf_persona_100_r any_bf_persona_r bf_empresa_r complete_r inconsistent_r aps_residual_0_r percent_declarado_r persona_prominent_r incomplete_r aps_residual_r cit_liability gross_profit taxable_profits cit_liability uti_reinvertir_cpz_3580_w taxable_profits_w gross_profit_w cit_liability_w tasa_ir tasa_ir_w

gen post = anio_fiscal >= 2015

//defining cuts based on incumbent bo reporting

// replace bf_persona_r = bf_persona if anio_fiscal == 2014 & aps == 1 & bf_persona != . & bf_persona_r == .
// replace bf_persona_r = 0 if missing(bf_persona_r) & anio_fiscal == 2014

bys firm_id: gegen bo_2014 = mean(cond(anio_fiscal == 2014, bf_persona_r, .))

gen bo_2014_group = 0 if bo_2014 == 0
	replace bo_2014_group = 1 if bo_2014 > 0 & bo_2014 < 100 & missing(bo_2014) == 0
	replace bo_2014_group = 2 if bo_2014 == 100 & missing(bo_2014) == 0
	replace bo_2014_group = 3 if missing(bo_2014_group)

gen bo_2014_treatment_group = 0 if treatment == 0
	replace bo_2014_treatment_group = 1 if bo_2014 == 0 & treatment == 1
	replace bo_2014_treatment_group = 2 if bo_2014 > 0 & bo_2014 < 100 & treatment == 1 & missing(bo_2014) == 0
	replace bo_2014_treatment_group = 3 if bo_2014 == 100 & treatment == 1 & missing(bo_2014) == 0
	replace bo_2014_treatment_group = 4 if missing(bo_2014_treatment_group)

gen bo_2014_treatment_group_alt = 0 if treatment == 0
	replace bo_2014_treatment_group_alt = 1 if bo_2014 < 100 & treatment == 1
	replace bo_2014_treatment_group_alt = 2 if bo_2014 == 100 & treatment == 1
	replace bo_2014_treatment_group_alt = 3 if missing(bo_2014_treatment_group)	
	
gen bo_2014_treatment_group_maj = 0 if treatment == 0
	replace bo_2014_treatment_group_maj = 1 if bo_2014 < 50 & treatment == 1
	replace bo_2014_treatment_group_maj = 2 if bo_2014 >= 50 & treatment == 1
	replace bo_2014_treatment_group_maj = 3 if missing(bo_2014_treatment_group_maj)
	
gen bo_2014_treatment_group_maj_alt = 0 if treatment == 0
	replace bo_2014_treatment_group_maj_alt = 2 if bo_2014 >= 50 & treatment == 1
	replace bo_2014_treatment_group_maj_alt = 1 if missing(bo_2014_treatment_group_maj_alt)

gen bo_2014_treatment_group_med = 0 if treatment == 0
sum bo_2014 if anio_fiscal == 2014 & treatment == 1, det
	replace bo_2014_treatment_group_med = 1 if bo_2014 < r(p50) & treatment == 1
	replace bo_2014_treatment_group_med = 2 if bo_2014 >= r(p50) & treatment == 1
	replace bo_2014_treatment_group_med = 3 if missing(bo_2014_treatment_group_med)
	
cap gen post = anio_fiscal >= 2015

compress

foreach v in bo_2014_treatment_group_med bo_2014_treatment_group bo_2014_group bo_2014 bo_2014_treatment_group_maj_alt bo_2014_treatment_group_maj bo_2014_treatment_group_alt  {

	if inlist("`v'", "bo_2014_treatment_group_maj_alt", "bo_2014_treatment_group_maj", "bo_2014_treatment_group_alt", "bo_2014_treatment_group", "bo_2014_treatment_group_med") {
		
		loc var = "b0.i.`v'"
		loc reg_spec = "discrete_dd"
		
	}
	
	else if "`v'" == "bo_2014_group" {
		
		loc var = "b0.i.`v'##b0.i.treatment"
		loc reg_spec = "discrete_ddd"
		
	}
	
	else if "`v'" == "bo_2014" {
		
		loc var = "c.`v'##b0.i.treatment"
		loc reg_spec = "continuous_ddd"
		
	}
	
// 	foreach y in aps f101 active aps_f101 aps_f101_active porcentaje_pff porcentaje_ext porcentaje_nac porcentaje_vac percent_declarado incomplete complete inconsistent aps_residual aps_residual_0 aps_residual_pais aps_residual_pais_other average_chain_length max_chain_length b_average_chain_length b_max_chain_length max_shareholder beneficiarios_pff beneficiarios_ext beneficiarios_nac beneficiarios_vac beneficiarios_10_pff beneficiarios_10_ext beneficiarios_10_nac beneficiarios_10_vac terminal_ownership_conc terminal_owners_10 terminal_owners participation_prominent participation_prominent_0 participation_inv_prominent intermediate_pff intermediate_ext intermediate_nac intermediate_vac intermediate_prominent intermediate_10_pff intermediate_10_ext intermediate_10_nac intermediate_10_vac intermediate_10_prominent intermediate_50_pff intermediate_50_ext intermediate_50_nac intermediate_50_vac intermediate_100_pff intermediate_pff_max intermediate_50_prominent intermediate_100_ext intermediate_100_prominent intermediate_inv_prominent intermediate_10_inv_prominent intermediate_50_inv_prominent intermediate_100_inv_prominent empresa_extranjera persona_extranjera persona_nacional empresa_pff persona_pff empresa_nacional persona_foreign empresa_foreign bf_persona bf_persona_100 any_bf_persona bf_empresa bf_persona_alt bf_persona_r persona_prominent bf_persona_100_r any_bf_persona_r bf_empresa_r complete_r inconsistent_r aps_residual_0_r percent_declarado_r persona_prominent_r incomplete_r aps_residual_r cit_liability gross_profit taxable_profits cit_liability uti_reinvertir_cpz_3580_w taxable_profits_w gross_profit_w cit_liability_w tasa_ir tasa_ir_w {
	
	foreach y in /*aps f101 active aps_f101 aps_f101_active porcentaje_pff porcentaje_ext*/ porcentaje_nac /*percent_declarado incomplete complete inconsistent aps_residual aps_residual_0 aps_residual_pais aps_residual_pais_other*/ max_shareholder terminal_ownership_conc terminal_owners_10 terminal_owners participation_prominent participation_inv_prominent /*intermediate_pff intermediate_ext intermediate_pff_alt intermediate_ext_alt intermediate_pff_int intermediate_ext_int intermediate_nac intermediate_prominent intermediate_inv_prominent*/ persona_nacional persona_pff persona_foreign bf_persona bf_persona_100 any_bf_persona bf_empresa bf_persona_alt bf_persona_r persona_prominent bf_persona_100_r any_bf_persona_r /*bf_empresa_r complete_r inconsistent_r aps_residual_0_r percent_declarado_r persona_prominent_r incomplete_r aps_residual_r*/ cit_liability_w taxable_profits_w gross_profit_w tasa_ir_w {
			
		//levels
		cap n reghdfe `y' `var'##b2014.i.anio_fiscal, cluster(firm_id) absorb(firm_id anio_fiscal)
		
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "levels", reg_spec, "`reg_spec'", design, "event_study") detail(scalars)
			
		cap n reghdfe `y' `var'##b0.i.post, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "levels", reg_spec, "`reg_spec'", design, "dd") detail(scalars)	
		
		//skipping if the variable is a binary variable
		qui sum `y'
		if round(((r(mean) * (1 - r(mean))) - (r(sd)^2)), .001) == 0 continue
		
		cap gen l_`y' = log(`y')
		cap gen b_`y' = `y' > 0 if missing(`y') == 0 
		
		//log
		cap n reghdfe l_`y' `var'##b2014.i.anio_fiscal, cluster(firm_id) absorb(firm_id anio_fiscal)
		
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "log", reg_spec, "`reg_spec'", design, "event_study") detail(scalars)
			
		cap n reghdfe l_`y' `var'##b0.i.post, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "log", reg_spec, "`reg_spec'", design, "dd") detail(scalars)	
			
		//poisson
		cap n ppmlhdfe `y' `var'##b2014.i.anio_fiscal if `y' >= 0, cluster(firm_id) absorb(firm_id anio_fiscal)
			
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "poisson", reg_spec, "`reg_spec'", design, "event_study") detail(scalars)
			
		cap n ppmlhdfe `y' `var'##b0.i.post if `y' >= 0, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "poisson", reg_spec, "`reg_spec'", design, "dd") detail(scalars)	
			
		//binary
		cap n reghdfe b_`y' `var'##b2014.i.anio_fiscal, cluster(firm_id) absorb(firm_id anio_fiscal)
			
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "binary", reg_spec, "`reg_spec'", design, "event_study") detail(scalars)
			
		cap n reghdfe b_`y' `var'##b0.i.post, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/bo_2014.dta", append autoid addlabel(indepvar, `v', depvar, `y', spec, "binary", reg_spec, "`reg_spec'", design, "dd") detail(scalars)	
		
	}

}	
	
cap postclose bo_2014

/*
/****************/
/* DESCRIPTIVES */
/****************/

use "$datadir/main_panel.dta", replace

//keeping majors
keep if missing(treatment_major) == 0
ren treatment_major treatment

gen post = anio_fiscal >= 2015

//defining cuts based on incumbent bo reporting
bys firm_id: gegen bo_2014 = mean(cond(anio_fiscal == 2014, bf_persona_r, .))

gen bo_2014_treatment_group = 0 if treatment == 0
	replace bo_2014_treatment_group = 1 if bo_2014 == 0 & treatment == 1
	replace bo_2014_treatment_group = 2 if bo_2014 > 0 & bo_2014 < 100 & treatment == 1 & missing(bo_2014) == 0
	replace bo_2014_treatment_group = 3 if bo_2014 == 100 & treatment == 1 & missing(bo_2014) == 0

gen bo_2014_t_c_group = 0 if bo_2014 == 0 & treatment == 0
	replace bo_2014_t_c_group = 1 if bo_2014 > 0 & bo_2014 < 100 & treatment == 0 & missing(bo_2014) == 0
	replace bo_2014_t_c_group = 2 if bo_2014 == 100 & treatment == 0 & missing(bo_2014) == 0
	replace bo_2014_t_c_group = 3 if bo_2014 == 0 & treatment == 1
	replace bo_2014_t_c_group = 4 if bo_2014 > 0 & bo_2014 < 100 & treatment == 1 & missing(bo_2014) == 0
	replace bo_2014_t_c_group = 5 if bo_2014 == 100 & treatment == 1 & missing(bo_2014) == 0
	
cap gen post = anio_fiscal >= 2015

compress

//need to pare down a lot

//not doing mid prominent or inverse groups, as these are implied by the groups
drop participation_inv_prominent ///
mid_div_salidas_prom mid_div_salidas_inv mid_div_entradas_prom mid_div_entradas_inv mid_fin_salidas_prom mid_fin_salidas_inv mid_fin_entradas_prom mid_fin_entradas_inv mid_all_salidas_prom mid_all_salidas_inv mid_all_entradas_prom mid_all_entradas_inv mid_div_salidas_prom_rr mid_div_salidas_prom_rr_w mid_div_salidas_inv_rr mid_div_salidas_inv_rr_w mid_div_entradas_prom_rr mid_div_entradas_prom_rr_w mid_div_entradas_inv_rr mid_div_entradas_inv_rr_w mid_fin_salidas_prom_rr mid_fin_salidas_prom_rr_w mid_fin_salidas_inv_rr mid_fin_salidas_inv_rr_w mid_fin_entradas_prom_rr mid_fin_entradas_prom_rr_w mid_fin_entradas_inv_rr mid_fin_entradas_inv_rr_w mid_all_salidas_prom_rr mid_all_salidas_prom_rr_w mid_all_salidas_inv_rr mid_all_salidas_inv_rr_w mid_all_entradas_prom_rr mid_all_entradas_prom_rr_w mid_all_entradas_inv_rr mid_all_entradas_inv_rr_w mid_all_salidas_prom_w mid_all_salidas_inv_w mid_all_entradas_prom_w mid_all_entradas_inv_w mid_div_salidas_prom_w mid_div_salidas_inv_w mid_div_entradas_prom_w mid_div_entradas_inv_w mid_fin_salidas_prom_w mid_fin_salidas_inv_w mid_fin_entradas_prom_w mid_fin_entradas_inv_w 

//other drops
drop group_assign group treatment treatment_minor exposure prominent_2014 tasa_vigente t_major_alt t_minor_alt c_major_alt c_minor_alt treatment_major_alt treatment_minor_alt exposure_alt prominent_2012_2014 porcion_comp_soc_no_inf_3576 porcion_comp_soc_si_inf_3578 aps_residual_pais_other porcentaje_vac beneficiarios_vac beneficiarios_10_vac intermediate_vac intermediate_10_vac intermediate_50_vac dummy_utilidad dummy_cero firm_id

//dropping winsorized variables, as just trying to describe raw variables
drop current_investment_w activos_c_w total_activos_fijos_690_w activos_intangibles_alt_w total_activos_lp_1070_w total_assets_w passive_c_w total_pasivos_int_1600_w total_passive_w total_capital_w dividendos_percibidos_w revenue_w total_cost_expenses_w gross_profit_w perdida_ejercicio_3430_w participacion_tbj_15_3440_w taxable_profits_w perdida_3570_w uti_reinvertir_cpz_3580_w cit_liability_w impuesto_renta_pagar_3680_w agregated_debt_int_w local_related_w local_unrelated_w foreign_related_w foreign_unrelated_w passive_c_related_local_w passive_c_unrelated_local_w passive_c_related_ext_w passive_c_unrelated_ext_w passive_l_related_local_w passive_l_unrelated_local_w passive_l_related_ext_w passive_l_unrelated_ext_w activos_intangibles_w investments_w inversiones_no_corrientes_w inversiones_lp_rel_w active_c_related_local_w active_c_unrelated_local_w active_c_related_ext_w active_c_unrelated_ext_w active_l_related_local_w active_l_unrelated_local_w active_l_related_ext_w active_l_unrelated_ext_w total_activos_netos_w debt_ratio_w tot_currentassets_net_w net_active_c_related_local_w net_active_c_unrel_local_w net_active_c_related_ext_w net_active_c_unrelated_ext_w net_active_l_related_local_w net_active_l_unrel_local_w net_active_l_related_ext_w net_active_l_unrelated_ext_w pagos_locales_w pagos_extranjeros_w labor_cost_w gastos_lab_w costos_lab_w exports_w local_sales_w total_sales_w labor_ratio_w taxable_profit_margin_w gross_profit_margin_w return_on_assets_w tasa_ir_w mid_div_salidas_pff_w mid_div_salidas_ext_w mid_div_entradas_pff_w mid_div_entradas_ext_w mid_fin_salidas_pff_w mid_fin_salidas_ext_w mid_fin_entradas_pff_w mid_fin_entradas_ext_w mid_all_salidas_pff_w mid_all_salidas_ext_w mid_all_entradas_pff_w mid_all_entradas_ext_w mid_fin_salidas_total_w mid_fin_entradas_total_w mid_div_salidas_total_w mid_div_entradas_total_w mid_all_salidas_total_w mid_all_entradas_total_w

gen count = 1

foreach v in current_investment activos_c total_activos_fijos_690 activos_intangibles_alt total_activos_lp_1070 total_assets passive_c total_pasivos_int_1600 total_passive total_capital dividendos_percibidos revenue total_cost_expenses gross_profit perdida_ejercicio_3430 participacion_tbj_15_3440 taxable_profits perdida_3570 uti_reinvertir_cpz_3580 cit_liability tasa_ir impuesto_renta_pagar_3680 agregated_debt_int local_related local_unrelated foreign_related foreign_unrelated passive_c_related_local passive_c_unrelated_local passive_c_related_ext passive_c_unrelated_ext passive_l_related_local passive_l_unrelated_local passive_l_related_ext passive_l_unrelated_ext activos_intangibles investments inversiones_no_corrientes inversiones_lp_rel active_c_related_local active_c_unrelated_local active_c_related_ext active_c_unrelated_ext active_l_related_local active_l_unrelated_local active_l_related_ext active_l_unrelated_ext total_activos_netos tot_currentassets_net net_active_c_related_local net_active_c_unrel_local net_active_c_related_ext net_active_c_unrelated_ext net_active_l_related_local net_active_l_unrel_local net_active_l_related_ext net_active_l_unrelated_ext pagos_locales pagos_extranjeros labor_cost gastos_lab costos_lab exports local_sales total_sales taxable_profit_margin gross_profit_margin return_on_assets mid_div_salidas_pff mid_div_salidas_ext mid_div_entradas_pff mid_div_entradas_ext mid_fin_salidas_pff mid_fin_salidas_ext mid_fin_entradas_pff mid_fin_entradas_ext mid_all_salidas_pff mid_all_salidas_ext mid_all_entradas_pff mid_all_entradas_ext mid_fin_salidas_total mid_fin_entradas_total mid_div_salidas_total mid_div_entradas_total mid_all_salidas_total mid_all_entradas_total {
	
	qui sum `v'
	if r(sd) == 0 continue
	
	cap n gen l_`v' = log(`v')
	
}

//smaller set for binaries
foreach v in mid_div_salidas_pff mid_div_salidas_ext mid_div_entradas_pff mid_div_entradas_ext mid_fin_salidas_pff mid_fin_salidas_ext mid_fin_entradas_pff mid_fin_entradas_ext mid_all_salidas_pff mid_all_salidas_ext mid_all_entradas_pff mid_all_entradas_ext mid_fin_salidas_total mid_fin_entradas_total mid_div_salidas_total mid_div_entradas_total mid_all_salidas_total mid_all_entradas_total gross_profit taxable_profits cit_liability {

	qui sum `v'
	if r(sd) == 0 continue
	
	cap n gen b_`v' = (`v') > 0 if missing(`v') == 0
	
}

foreach d in /*bo_2014_treatment_group*/ bo_2014_t_c_group {

	//reset variable collectors
	local meanlist = ""
	local sdlist = ""
	local p10list = ""
	local p50list = ""
	local p90list = ""
	
	preserve 
		
		ds count bo_2014_treatment_group bo_2014_t_c_group anio_fiscal, not

		foreach v in `r(varlist)' {
				
			loc l = length("s_`v'")
			if `l' >= 33 di "s_`v' is `l'"
			
			local meanlist = "`meanlist'"+ " m_`v' = `v'"
			
			//not producing percentiles or sd for binaries
			if substr("`v'", 1, 2) == "b_"  continue
			
			qui sum `v'
			if round(((r(mean) * (1 - r(mean))) - (r(sd)^2)), .001) == 0 continue
			
			local sdlist = "`sdlist'" + " s_`v' = `v'"
			local p10list = "`p10list'" + " `v'10 = `v'"
			local p50list = "`p50list'" + " `v'50 = `v'"
			local p90list = "`p90list'" + " `v'90 = `v'"

			
		}

		gcollapse (sum) count (mean) `meanlist' (sd) `sdlist' (p10) `p10list' (p50) `p50list' (p90) `p90list', by(`d' anio_fiscal)

		save "$outdir/bo_2014_collapsed_`d'.dta", replace

	restore
	
}
*/

/*******/
/* END */
/*******/

timer off 1 

loc time1 = "$S_TIME"
loc date1 = "$S_DATE"

di "started: `time0' `date0'"
di "ended: `time1' `date1'"

timer list 
di "elapsed time: `r(t1)' seconds"

di "file bo_2014 has terminated successfully"

cap log close
clear
