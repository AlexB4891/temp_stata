cap clear all
set more off
cap log close
set varabbrev off

loc extract_date = "202603013"

/***********/
/* HISTORY */
/***********/
	
//20260304: main ownership results, restricting on firms with always positive assets, always positive revenues, always positive both
	
/*********/
/* NOTES */
/*********/

/***************************/
/* JAKOB LOCAL ENVIRONMENT */
/***************************/

/*
local today: di %tdCYND daily("$S_DATE", "DMY")
local month = substr("`today'", 1, 6)

glob localdir "/Users/jakob_brounstein/Dropbox/ecuador_transparency"
glob mydatadir "$localdir/data/local_simulation"
glob datadir "$localdir/data/local_simulation"
glob dodir "$localdir/do"
glob logdir "$localdir/logs"

glob graphdir "$localdir/local_simulation"
glob texdir "$localdir/local_simulation"

cap n mkdir "$localdir/local_simulation/resultados"

//export directory
cap n mkdir "$localdir/local_simulation/resultados/`today'"
cap n mkdir "$localdir/local_simulation/resultados/`today'/reportes"
glob outdir "$localdir/local_simulation/resultados/`today'/reportes"

log using "$logdir/main_ownership_results_`today'.smcl", replace

loc time0 = "$S_TIME"
loc date0 = "$S_DATE"

di "started: `time0' `date0'"

sca local_environment = 1

timer clear
timer on 1  
*/

/*******************/
/* SRI ENVIRONMENT */
/*******************/

local today: di %tdCYND daily("$S_DATE", "DMY")
local month = substr("`today'", 1, 6)

glob localdir "D:\BM_EXTENSION\B202106_JAKOB_BROUNSTEIN"

//alt
/*
glob localdir "F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN"
sysdir set PLUS F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN\Ado\ado_1\plus
sysdir set PERSONAL F:\DTO_ESTUDIOS_E1_ext2\B_INVESTIGADORES_EXTERNOS\B202106_JAKOB_BROUNSTEIN\Ado\ado\plus
*/

cap n mkdir "$localdir/resultados"

glob logdir "$localdir\logs"
glob dumpdir "$localdir\dump"
glob datadir "$localdir/data/transparency"
glob graphdir "$localdir/out"
glob texdir "$localdir/out"

//export directory
cap n mkdir "$localdir/resultados/`extract_date'"
cap n mkdir "$localdir/resultados/`extract_date'/reportes"
glob outdir "$localdir/resultados/`extract_date'/reportes"

log using "$logdir/main_ownership_results_`today'.smcl", replace

loc time0 = "$S_TIME"
loc date0 = "$S_DATE"

di "started: `time0' `date0'"

timer clear
timer on 1  

/**************************/
/* MAIN OWNERSHIP RESULTS */
/**************************/

use "$datadir/main_panel.dta", clear

keep if missing(treatment_major) == 0
ren treatment_major treatment

merge m:1 firm_id using "$datadir/industries.dta", keep(1 3) gen(industry_merge)

///
//generate TFP
///
foreach v in revenue total_assets labor_cost {
	
	cap gen l_`v' = log(`v')
	
}

reg l_revenue l_total_assets l_labor_cost
predict tfp_unsaturated, resid

reghdfe l_revenue l_total_assets l_labor_cost, absorb(anio_fiscal) resid
predict tfp_yearfe, resid

reghdfe l_revenue l_total_assets l_labor_cost, absorb(anio_fiscal industry1) resid
predict tfp_yearindustryfe, resid

///
//generate labor expense alt
///

gen labor_expense_alt = labor_cost
	replace labor_expense_alt = 292 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2012
	replace labor_expense_alt = 318 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2013
	replace labor_expense_alt = 340 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2014
	replace labor_expense_alt = 354 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2015
	replace labor_expense_alt = 366 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2016
	replace labor_expense_alt = 375 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2017
	replace labor_expense_alt = 386 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2018
	replace labor_expense_alt = 394 * 12 if inlist(labor_expense_alt, 0 , .) & anio_fiscal == 2019

ren anio_fiscal year
merge m:1 year using "$datadir/cpi_year.dta", nogen keep(3) keepus(cpi2014)
ren year anio_fiscal

replace labor_expense_alt = labor_expense_alt * 100 / cpi2014

drop cpi2014

///
//generating alt assets
///
gen total_assets_alt = total_assets

gsort firm_id anio_fiscal

//carry forward
replace total_assets_alt = total_assets_alt[_n-1] if inlist(total_assets_alt, ., 0) & firm_id == firm_id[_n-1]

//pull back
replace total_assets_alt = total_assets_alt[_n+1] if inlist(total_assets_alt, ., 0) & firm_id == firm_id[_n+1]

gstats winsor total_assets_alt, by(anio_fiscal group) cuts(1 99) replace

///
//generating other outcomes
///

foreach v in domestic_dividends dividends mid_div_salidas_total retained_earnings investments labor_cost gastos_lab costos_lab  {
	
	cap gen `v'_ps = `v' / gross_profit
	
	cap gen `v'_ps_w = `v' / gross_profit
		cap replace `v'_ps_w = 1 if `v'_ps_w > 1 & missing(`v'_ps_w) == 0
	
}	
	
foreach v in domestic_dividends dividends mid_div_salidas_total investments retained_earnings mid_div_salidas_pff mid_fin_salidas_pff mid_all_salidas_pff mid_div_salidas_prom mid_fin_salidas_prom mid_all_salidas_prom labor_cost gastos_lab costos_lab {
	
	cap gen `v'_ar = `v' / total_assets
	
	cap gen `v'_ar_w = `v' / total_assets
		cap replace `v'_ar_w = 1 if `v'_ar_w > 1 & missing(`v'_ar_w) == 0
		
	cap gen `v'_ara = `v' / total_assets_alt
	
	cap gen `v'_ara_w = `v' / total_assets_alt
		cap replace `v'_ara_w = 1 if `v'_ar_w > 1 & missing(`v'_ar_w) == 0	
	
}

gen post = anio_fiscal >= 2015

gen b_participation_prominent = participation_prominent > 0 if missing(participation_prominent) == 0
gen b_participation_inv_prominent = participation_inv_prominent > 0 if missing(participation_inv_prominent) == 0

gegen any_prom_presence_int = rowmax(intermediate_prom_int b_participation_prominent)
gegen any_prom_presence_alt = rowmax(intermediate_prom_alt b_participation_prominent)

gegen any_haven_presence_int = rowmax(intermediate_pff_int b_participation_prominent)
gegen any_haven_presence_alt = rowmax(intermediate_pff_alt b_participation_prominent)

gegen any_prom_presence_intalt = rowmax(intermediate_prom_alt b_participation_prominent)
	replace any_prom_presence_intalt = . if intermediate_prom_alt == .
	
gegen any_haven_presence_intalt = rowmax(intermediate_pff_alt b_participation_prominent)
	replace any_haven_presence_intalt = . if intermediate_pff_alt == .
	
gegen any_inv_prom_presence_int = rowmax(intermediate_inv_prom_int b_participation_prominent)
gegen any_inv_prom_presence_alt = rowmax(intermediate_inv_prom_alt b_participation_prominent)

gegen any_nonhaven_presence_int = rowmax(intermediate_ext_int b_participation_prominent)
gegen any_nonhaven_presence_alt = rowmax(intermediate_ext_alt b_participation_prominent)

foreach v in 10 50 100 {
	
	gegen any_prom_`v'_presence_int = rowmax(intermediate_`v'_prom_int b_participation_prominent)
	gegen any_prom_`v'_presence_alt = rowmax(intermediate_`v'_prom_alt b_participation_prominent)

	gegen any_haven_`v'_presence_int = rowmax(intermediate_`v'_pff_int b_participation_prominent)
	gegen any_haven_`v'_presence_alt = rowmax(intermediate_`v'_pff_alt b_participation_prominent)
	
	gegen any_prom_`v'_presence_intalt = rowmax(intermediate_`v'_prom_alt b_participation_prominent)	
		replace any_prom_`v'_presence_intalt = . if intermediate_`v'_prom_alt == .
		
	gegen any_haven_`v'_presence_intalt = rowmax(intermediate_`v'_pff_alt b_participation_prominent)
		replace any_haven_`v'_presence_intalt = . if intermediate_`v'_pff_alt == .
		
	gegen any_inv_prom_`v'_presence_int = rowmax(intermediate_`v'_inv_prom_int b_participation_inv_prominent)
	gegen any_inv_prom_`v'_presence_alt = rowmax(intermediate_`v'_inv_prom_alt b_participation_inv_prominent)
	
	gegen any_nonhaven_`v'_presence_int = rowmax(intermediate_`v'_ext_int b_participation_inv_prominent)
	gegen any_nonhaven_`v'_presence_alt = rowmax(intermediate_`v'_ext_alt b_participation_inv_prominent)
	
}

gegen passive_unrelated_local = rowtotal(passive_c_unrelated_local passive_l_unrelated_local)
gegen passive_unrelated_ext = rowtotal(passive_c_unrelated_ext passive_l_unrelated_ext)
gegen passive_related_local = rowtotal(passive_c_related_local passive_l_related_local)
gegen passive_related_ext = rowtotal(passive_c_related_ext passive_l_related_ext)

gegen passive_related = rowtotal(passive_related_local passive_related_ext)
gegen passive_alt = rowtotal(passive_related_local passive_related_ext passive_unrelated_local passive_unrelated_ext)

gegen active_unrelated_local = rowtotal(active_c_unrelated_local active_l_unrelated_local)
gegen active_unrelated_ext = rowtotal(active_c_unrelated_ext active_l_unrelated_ext)
gegen active_related_local = rowtotal(active_c_related_local active_l_related_local)
gegen active_related_ext = rowtotal(active_c_related_ext active_l_related_ext)

gegen active_related = rowtotal(active_related_local active_related_ext)
gegen active_alt = rowtotal(active_related_local active_related_ext active_unrelated_local active_unrelated_ext)

//year-to-year increase variables
gsort firm_id + anio_fiscal

foreach v in investments mid_div_salidas_pff mid_div_salidas_pff_rr mid_all_salidas_pff mid_all_salidas_prom mid_all_salidas_pff_rr mid_all_salidas_prom_rr debt_ratio total_assets total_passive labor_cost labor_ratio foreign_related_w local_related_w passive_related_ext passive_related_local {

	gen b_`v'_inc = `v' > `v'[_n-1] if firm_id == firm_id[_n-1] & missing(`v') == 0 & missing(`v'[_n-1]) == 0
	gen b_`v'_dec = `v' < `v'[_n-1] if firm_id == firm_id[_n-1] & missing(`v') == 0 & missing(`v'[_n-1]) == 0
	
}

///
//GENERATING CHECKS ON ALWAYS POSITIVE ASSETS, ALWAYS POSITIVE LABOR, ALWAYS POSITIVE BOTH
///

bys firm_id: gegen max_filing_year = max(cond(f101 == 1, anio_fiscal, .))
bys firm_id: gegen min_filing_year = min(cond(f101 == 1, anio_fiscal, .))

bys firm_id: gegen years_positive_assets = count(cond(inrange(anio_fiscal, min_filing_year, max_filing_year) & total_assets > 0 & total_assets != ., total_assets, .))
bys firm_id: gegen years_positive_labor = count(cond(inrange(anio_fiscal, min_filing_year, max_filing_year) & labor_cost > 0 & labor_cost != ., labor_cost, .))

gen full_labor_assets_sample = (years_positive_labor == max_filing_year - min_filing_year + 1) & (years_positive_assets == max_filing_year - min_filing_year + 1)

drop years_positive_labor years_positive_assets min_filing_year max_filing_year

///
//UNWEIGHTED
///

preserve
	
	keep if full_labor_assets_sample == 1
	
	cap postclose main_ownership_results_fb
	postfile main_ownership_results_fb str32(var) double(coef stderr N r2) using "$outdir/main_ownership_results_fb.dta", replace

	ds post firm_id anio_fiscal group_assign group treatment treatment_minor exposure prominent_2014 t_major_alt t_minor_alt c_major_alt c_minor_alt treatment_major_alt treatment_minor_alt exposure_alt prominent_2012_2014 porcion_comp_soc_no_inf_3576 porcion_comp_soc_si_inf_3578, not

	foreach y in `r(varlist)' {	
		
		//levels
		cap n reghdfe `y' b0.i.treatment##b2014.i.anio_fiscal, cluster(firm_id) absorb(firm_id anio_fiscal)
		
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "levels", design, "event_study") detail(scalars)
			
		cap n reghdfe `y' b0.i.treatment##b0.i.post, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "levels", design, "dd") detail(scalars)	

		//skipping if the variable is a binary variable
		qui sum `y'
		if round(((r(mean) * (1 - r(mean))) - (r(sd)^2)), .001) == 0 continue

		cap gen l_`y' = log(`y')
		cap gen b_`y' = `y' > 0 if missing(`y') == 0
		
		//log
		cap n reghdfe l_`y' b0.i.treatment##b2014.i.anio_fiscal, cluster(firm_id) absorb(firm_id anio_fiscal)
		
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "log", design, "event_study") detail(scalars)
			
		cap n reghdfe l_`y' b0.i.treatment##b0.i.post, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "log", design, "dd") detail(scalars)	
			
		//poisson
		cap n ppmlhdfe `y' b0.i.treatment##b2014.i.anio_fiscal if `y' >= 0, cluster(firm_id) absorb(firm_id anio_fiscal)
			
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "poisson", design, "event_study") detail(scalars)
			
		cap n ppmlhdfe `y' b0.i.treatment##b0.i.post if `y' >= 0, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "poisson", design, "dd") detail(scalars)	
		
		if strpos("`y'", "_rr") != 0 continue 
		
		//binary
		cap n reghdfe b_`y' b0.i.treatment##b2014.i.anio_fiscal, cluster(firm_id) absorb(firm_id anio_fiscal)
			
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "binary", design, "event_study") detail(scalars)
			
		cap n reghdfe b_`y' b0.i.treatment##b0.i.post, cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "binary", design, "dd") detail(scalars)	
		
	}

	cap postclose main_ownership_results_fb

restore

///
//WEIGHTED
///

bys firm_id: gegen assets_2014 = total(cond(anio_fiscal == 2014, round(total_assets), .))
replace assets_2014 = round(assets_2014)

preserve
	
	keep if full_labor_assets_sample == 1
	
	cap postclose main_ownership_results_w_fb
	postfile main_ownership_results_w_fb str32(var) double(coef stderr N r2) using "$outdir/main_ownership_results_w_fb.dta", replace

	ds post firm_id anio_fiscal group_assign group treatment treatment_minor exposure prominent_2014 t_major_alt t_minor_alt c_major_alt c_minor_alt treatment_major_alt treatment_minor_alt exposure_alt prominent_2012_2014 porcion_comp_soc_no_inf_3576 porcion_comp_soc_si_inf_3578, not

	foreach y in `r(varlist)' {	
		
		//levels
		cap n reghdfe `y' b0.i.treatment##b2014.i.anio_fiscal [aweight = assets_2014], cluster(firm_id) absorb(firm_id anio_fiscal)
		
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "levels", design, "event_study") detail(scalars)
			
		cap n reghdfe `y' b0.i.treatment##b0.i.post [aweight = assets_2014], cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "levels", design, "dd") detail(scalars)	

		//skipping if the variable is a binary variable
		qui sum `y'
		if round(((r(mean) * (1 - r(mean))) - (r(sd)^2)), .001) == 0 continue

		cap gen l_`y' = log(`y')
		cap gen b_`y' = `y' > 0 if missing(`y') == 0
		
		//log
		cap n reghdfe l_`y' b0.i.treatment##b2014.i.anio_fiscal [aweight = assets_2014], cluster(firm_id) absorb(firm_id anio_fiscal)
		
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "log", design, "event_study") detail(scalars)
			
		cap n reghdfe l_`y' b0.i.treatment##b0.i.post [aweight = assets_2014], cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "log", design, "dd") detail(scalars)	
			
		//poisson
		cap n ppmlhdfe `y' b0.i.treatment##b2014.i.anio_fiscal if `y' >= 0 [fweight = assets_2014], cluster(firm_id) absorb(firm_id anio_fiscal)
			
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "poisson", design, "event_study") detail(scalars)
			
		cap n ppmlhdfe `y' b0.i.treatment##b0.i.post i.anio_fiscal if `y' >= 0 [fweight = assets_2014], cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "poisson", design, "dd") detail(scalars)	
		
		if strpos("`y'", "_rr") != 0 continue 
		
		//binary
		cap n reghdfe b_`y' b0.i.treatment##b2014.i.anio_fiscal [aweight = assets_2014], cluster(firm_id) absorb(firm_id anio_fiscal)
			
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "binary", design, "event_study") detail(scalars)
			
		cap n reghdfe b_`y' b0.i.treatment##b0.i.post [aweight = assets_2014], cluster(firm_id) absorb(firm_id)
		
			if !_rc regsave using "$outdir/main_ownership_results_w_fb.dta", append autoid addlabel(indepvar, "treatment_major", depvar, `y', spec, "binary", design, "dd") detail(scalars)	
		
	}

	cap postclose main_ownership_results_w_fb

restore
	
/////
///
//WHO ARE FIRMS THAT NEVER REPORT ASSETS?
///
/////	

use "$datadir/main_panel.dta", clear

bys firm_id: gegen max_filing_year = max(cond(f101 == 1, anio_fiscal, .))
bys firm_id: gegen min_filing_year = min(cond(f101 == 1, anio_fiscal, .))

gen non_positive_assets = inlist(total_assets, 0, .) | total_assets < 0
bys firm_id: gegen years_non_positive_assets = total(cond(inrange(anio_fiscal, min_filing_year, max_filing_year), non_positive_assets, .))

gen never_positive_assets = (years_non_positive_assets == max_filing_year - min_filing_year + 1)
gen never8_positive_assets = years_non_positive_assets == 8

foreach v in participation_inv_prominent ///
mid_div_salidas_prom mid_div_salidas_inv mid_div_entradas_prom mid_div_entradas_inv mid_fin_salidas_prom mid_fin_salidas_inv mid_fin_entradas_prom mid_fin_entradas_inv mid_all_salidas_prom mid_all_salidas_inv mid_all_entradas_prom mid_all_entradas_inv mid_div_salidas_prom_rr mid_div_salidas_prom_rr_w mid_div_salidas_inv_rr mid_div_salidas_inv_rr_w mid_div_entradas_prom_rr mid_div_entradas_prom_rr_w mid_div_entradas_inv_rr mid_div_entradas_inv_rr_w mid_fin_salidas_prom_rr mid_fin_salidas_prom_rr_w mid_fin_salidas_inv_rr mid_fin_salidas_inv_rr_w mid_fin_entradas_prom_rr mid_fin_entradas_prom_rr_w mid_fin_entradas_inv_rr mid_fin_entradas_inv_rr_w mid_all_salidas_prom_rr mid_all_salidas_prom_rr_w mid_all_salidas_inv_rr mid_all_salidas_inv_rr_w mid_all_entradas_prom_rr mid_all_entradas_prom_rr_w mid_all_entradas_inv_rr mid_all_entradas_inv_rr_w mid_all_salidas_prom_w mid_all_salidas_inv_w mid_all_entradas_prom_w mid_all_entradas_inv_w mid_div_salidas_prom_w mid_div_salidas_inv_w mid_div_entradas_prom_w mid_div_entradas_inv_w mid_fin_salidas_prom_w mid_fin_salidas_inv_w mid_fin_entradas_prom_w mid_fin_entradas_inv_w tasa_vigente treatment_major treatment_minor exposure prominent_2014 t_major_alt t_minor_alt c_major_alt c_minor_alt treatment_major_alt treatment_minor_alt exposure_alt prominent_2012_2014 porcion_comp_soc_no_inf_3576 porcion_comp_soc_si_inf_3578 aps_residual_pais_other porcentaje_vac beneficiarios_vac beneficiarios_10_vac intermediate_vac intermediate_10_vac intermediate_50_vac dummy_utilidad dummy_cero firm_id group_assign current_investment_w activos_c_w total_activos_fijos_690_w activos_intangibles_alt_w total_activos_lp_1070_w passive_c_w total_pasivos_int_1600_w total_passive_w total_capital_w dividendos_percibidos_w perdida_ejercicio_3430_w participacion_tbj_15_3440_w perdida_3570_w uti_reinvertir_cpz_3580_w impuesto_renta_pagar_3680_w agregated_debt_int_w local_related_w local_unrelated_w foreign_related_w foreign_unrelated_w passive_c_related_local_w passive_c_unrelated_local_w passive_c_related_ext_w passive_c_unrelated_ext_w passive_l_related_local_w passive_l_unrelated_local_w passive_l_related_ext_w passive_l_unrelated_ext_w activos_intangibles_w investments_w inversiones_no_corrientes_w inversiones_lp_rel_w active_c_related_local_w active_c_unrelated_local_w active_c_related_ext_w active_c_unrelated_ext_w active_l_related_local_w active_l_unrelated_local_w active_l_related_ext_w active_l_unrelated_ext_w total_activos_netos_w tot_currentassets_net_w net_active_c_related_local_w net_active_c_unrel_local_w net_active_c_related_ext_w net_active_c_unrelated_ext_w net_active_l_related_local_w net_active_l_unrel_local_w net_active_l_related_ext_w net_active_l_unrelated_ext_w pagos_locales_w pagos_extranjeros_w gastos_lab_w costos_lab_w local_sales_w total_sales_w mid_div_salidas_pff_w mid_div_salidas_ext_w mid_div_entradas_pff_w mid_div_entradas_ext_w mid_fin_salidas_pff_w mid_fin_salidas_ext_w mid_fin_entradas_pff_w mid_fin_entradas_ext_w mid_fin_salidas_total_w mid_fin_entradas_total_w mid_div_salidas_total_w mid_div_entradas_total_w {
	
	cap drop `v'
	
}

gen count = 1

foreach v in gross_profit_margin_w_alt gross_profit_margin gross_profit_margin_w return_on_assets_w_alt return_on_assets return_on_assets_w roa_2014 roa_2014_w_alt roa_2014_w porcentaje_pff porcentaje_nac porcentaje_ext current_investment activos_c total_activos_fijos_690 activos_intangibles_alt total_activos_lp_1070 total_assets total_assets_w passive_c total_pasivos_int_1600 total_passive total_capital dividendos_percibidos revenue revenue_w total_cost_expenses total_cost_expenses_w gross_profit gross_profit_w perdida_ejercicio_3430 participacion_tbj_15_3440 taxable_profits perdida_3570 uti_reinvertir_cpz_3580 cit_liability cit_liability_w tasa_ir impuesto_renta_pagar_3680 agregated_debt_int local_related local_unrelated foreign_related foreign_unrelated passive_c_related_local passive_c_unrelated_local passive_c_related_ext passive_c_unrelated_ext passive_l_related_local passive_l_unrelated_local passive_l_related_ext passive_l_unrelated_ext activos_intangibles investments inversiones_no_corrientes inversiones_lp_rel active_c_related_local active_c_unrelated_local active_c_related_ext active_c_unrelated_ext active_l_related_local active_l_unrelated_local active_l_related_ext active_l_unrelated_ext total_activos_netos tot_currentassets_net net_active_c_related_local net_active_c_unrel_local net_active_c_related_ext net_active_c_unrelated_ext net_active_l_related_local net_active_l_unrel_local net_active_l_related_ext net_active_l_unrelated_ext pagos_locales pagos_extranjeros labor_cost labor_cost_w gastos_lab costos_lab exports exports_w local_sales total_sales taxable_profit_margin mid_div_salidas_pff mid_div_salidas_ext mid_div_entradas_pff mid_div_entradas_ext mid_fin_salidas_pff mid_fin_salidas_ext mid_fin_entradas_pff mid_fin_entradas_ext mid_all_salidas_pff mid_all_salidas_ext mid_all_entradas_pff mid_all_entradas_ext mid_fin_salidas_total mid_fin_entradas_total mid_div_salidas_total mid_div_entradas_total mid_all_salidas_total mid_all_entradas_total dividends_w domestic_dividends_w retained_earnings_w profits_accumulated_w dividends domestic_dividends retained_earnings profits_accumulated {
	
	qui cap sum `v'
	if r(sd) == 0 continue
	
	cap n gen l_`v' = log(`v')
	
}

//smaller set for binaries
foreach v in mid_div_salidas_pff mid_div_salidas_ext mid_div_entradas_pff mid_div_entradas_ext mid_fin_salidas_pff mid_fin_salidas_ext mid_fin_entradas_pff mid_fin_entradas_ext mid_all_salidas_pff mid_all_salidas_ext mid_all_entradas_pff mid_all_entradas_ext mid_fin_salidas_total mid_fin_entradas_total mid_div_salidas_total mid_div_entradas_total mid_all_salidas_total mid_all_entradas_total gross_profit taxable_profits cit_liability dividends domestic_dividends {

	qui cap sum `v'
	if r(sd) == 0 continue
	
	cap n gen b_`v' = (`v') > 0 if missing(`v') == 0
	
}

cap drop *_rr_w
cap drop *_ps_w
cap drop *_ar_w
cap drop *_prom_*
cap drop *_inv_*
cap drop *net_active*
cap drop *div_entradas*
cap drop *fin_entradas*

cap drop industry1

ds count group anio_fiscal, not

foreach v in `r(varlist)' {
		
	loc l = length("`v'")
	if `l' >= 31 continue
	
	local meanlist = "`meanlist'"+ " m_`v' = `v'"
	local countlist = "`countlist'"+ " c_`v' = `v'"
	
	//not producing percentiles or sd for binaries
	if substr("`v'", 1, 2) == "b_"  continue
	
	qui sum `v'
	if round(((r(mean) * (1 - r(mean))) - (r(sd)^2)), .001) == 0 continue
	
	local sdlist = "`sdlist'" + " s_`v' = `v'"
	local p10list = "`p10list'" + " `v'10 = `v'"
	local p50list = "`p50list'" + " `v'50 = `v'"
	local p90list = "`p90list'" + " `v'90 = `v'"
	local p99list = "`p99list'"+ " `v'99 = `v'"
	local maxlist = "`maxlist'"+ " u_`v' = `v'"
	local minlist = "`minlist'"+ " b_`v' = `v'"
	
}

//BY GROUP X YEAR
preserve

	gcollapse (sum) count (mean) `meanlist' (sd) `sdlist' (p10) `p10list' (p50) `p50list' (p90) `p90list', by(group anio_fiscal never_positive_assets)

	save "$outdir/never_positive_assets_series.dta", replace

restore	

//BY GROUP X YEAR
preserve

	gcollapse (sum) count (mean) `meanlist' (sd) `sdlist' (p10) `p10list' (p50) `p50list' (p90) `p90list', by(group anio_fiscal never8_positive_assets)

	save "$outdir/never8_positive_assets_series.dta", replace

restore	
	
/*******/
/* END */
/*******/

timer off 1 

loc time1 = "$S_TIME"
loc date1 = "$S_DATE"

di "started: `time0' `date0'"
di "ended: `time1' `date1'"

timer list 
di "elapsed time: `r(t1)' seconds"

di "file main_ownership_panel_balance_robustness has terminated successfully"

cap log close
clear
